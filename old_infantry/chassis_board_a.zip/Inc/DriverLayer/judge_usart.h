#ifndef __JUDGE_USART_H
#define __JUDGE_USART_H

#include "main.h"

void DRV_USART3_IRQHandler(void);
void USART3_Init(void);
                                 
#endif